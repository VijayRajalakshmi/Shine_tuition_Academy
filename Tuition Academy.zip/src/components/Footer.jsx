import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        {/* Left Section */}
        <div className="footer-section">
          <h3>Shine Tuition Academy</h3>
          <p>Empowering students through quality education.</p>
          <p><i className="fas fa-map-marker-alt"></i> 13, Dayasadan St, Pallavan Nagar, Nerkundram, Chennai, Tamil Nadu 600107</p>
          <p><i className="fas fa-phone"></i> +91 98409 70732</p>
          <p><i className="fas fa-envelope"></i> shineacademy@email.com</p>
        </div>

        {/* Center Section - Quick Links */}
        <div className="footer-section">
          <h4>Quick Links</h4>
          <div className="footer-links">
            <div><a href="/">Home</a></div>
            <div><a href="/about">About</a></div>
            <div><a href="/courses">Courses</a></div>
            <div><a href="/testimonials">Testimonials</a></div>
            <div><a href="/tutors">Tutors</a></div>
            <div><a href="/contact">Contact</a></div>
            <div><a href="/faq">FAQ</a></div>
            <div><a href="/contact" className="cta-link">Get in Touch</a></div>
          </div>
        </div>

        {/* Right Section - Social */}
        <div className="footer-section">
          <h4>Follow Us</h4>
          <div className="social-icons">
            <a href="#"><i className="fab fa-facebook"></i></a>
            <a href="#"><i className="fab fa-instagram"></i></a>
            <a href="#"><i className="fab fa-youtube"></i></a>
            <a href="#"><i className="fab fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <hr />
      <p className="footer-bottom">© 2025 Shine Tuition Academy. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
