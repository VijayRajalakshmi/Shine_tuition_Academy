import './About.css';
import tuition1 from '../assets/tuition_1.jpg';
import tuition2 from '../assets/tuition_2.jpg';

function About() {
  return (
    <section className="about">
      <div className="about-container">
        {/* About Us Heading at the top */}
        <h2 className="about-heading">About Us</h2>

        <div className="about-images">
          <div className="image-section">
            <img src={tuition1} alt="Online Coaching" className="about-img" />
            <ul className="image-points">
              <li>✅ Online & Offline coaching actively conducted</li>
              <li>✅ Regular interactive sessions and assessments</li>
              <li>✅ Focus on conceptual clarity and real-time doubts</li>
            </ul>
          </div>

          <div className="image-section">
            <img src={tuition2} alt="Experienced Tutors" className="about-img" />
            <ul className="image-points">
              <li>✅ Coaching staff with 10+ years of experience</li>
              <li>✅ Subject-wise specialists available</li>
              <li>✅ Friendly, supportive and highly skilled faculty</li>
            </ul>
          </div>
        </div>

        <div className="about-text">
          <p>
            With over 3 years of excellence in both online and offline coaching, Shine Tuition Academy helps students
            master core subjects with personal attention, innovative teaching methods, and expert guidance.
          </p>
          <p>
            Our mission is to make learning effective and enjoyable, whether you're at home or in our center in Chennai.
            Join hundreds of happy learners and unlock your academic potential today!
          </p>
        </div>
      </div>
    </section>
  );
}

export default About;
